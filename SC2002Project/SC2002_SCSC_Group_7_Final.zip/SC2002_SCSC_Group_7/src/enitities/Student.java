package enitities;
import java.util.ArrayList;



public class Student extends User {
    private ArrayList<String> committeeCamp;
    private ArrayList<String> attendeeCamp;
    private ArrayList<String> blackListCamp;
    private int points;
    public static final int MAX_COMM_PART = 1;

    public Student(String name, String email, Faculty faculty, String networkID, Password password, ArrayList<String> committeeCamp, ArrayList<String> attendeeCamp, int points, ArrayList<String> blackListCamp) {
        super(name, email, faculty, networkID, password);
        this.committeeCamp = new ArrayList<>(committeeCamp);
        this.attendeeCamp = new ArrayList<>(attendeeCamp);
        this.blackListCamp = new ArrayList<>(blackListCamp);
        this.points = points;
    }

    public ArrayList<String> getCampCommittee() {
        return this.committeeCamp;
    }

    public ArrayList<String> getCampAttendee() {
        return this.attendeeCamp;
    }

    public void setCampCommittee(ArrayList<String> newCommitteeCamp) {
        this.committeeCamp = new ArrayList<>(newCommitteeCamp);
    }

    public void setCampAttendee(ArrayList<String> newAttendeeCamp) {
        this.attendeeCamp = new ArrayList<>(newAttendeeCamp);
    }

    public int getPoints() {
        return this.points;
    }

    public void addPoints(int num) {
        this.points += num;
    }

    // Getter for blackListCamp
    public ArrayList<String> getBlackListCamp() {
        return this.blackListCamp;
    }

    // Setter for blackListCamp
    public void setBlackListCamp(ArrayList<String> newBlackListCamp) {
        this.blackListCamp = new ArrayList<>(newBlackListCamp);
    }
    public void addToBlackListCamp(String campName){
        blackListCamp.add(campName);
    }

    public void removeFromAttendeeCamp(String campName){
        attendeeCamp.remove(campName);
    }

    public void addToAttendeeCamp(String campName){
        attendeeCamp.add(campName);
    }

    public void addToCommitteeCamp(String campName){
        committeeCamp.add(campName);
    }

    public static int getMAX(){
        return MAX_COMM_PART;
    }
}
