package enitities;
import java.util.ArrayList;



public class Staff extends User {
    private ArrayList<String> createdCamps;

    public Staff(String name, String email, Faculty faculty, String networkID, Password password, ArrayList<String> createdCamps) {
        super(name, email, faculty, networkID, password);
        this.createdCamps = new ArrayList<>(createdCamps); 
    }
    public Staff(){

    }

    public ArrayList<String> getCreatedCamps() {
        return this.createdCamps;
    }

    public void setCreatedCamps(ArrayList<String> newCreatedCamps) {
        this.createdCamps = new ArrayList<>(newCreatedCamps);
    }

    public void addToCreatedCamps(String campName){
        createdCamps.add(createdCamps.size(), campName);
    }
}
