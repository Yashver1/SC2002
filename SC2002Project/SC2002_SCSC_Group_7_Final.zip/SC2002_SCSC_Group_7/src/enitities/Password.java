package enitities;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
// need change method names in UML

public class Password {
    private String HashedPassword;

    public Password(String hashedPassword) throws NoSuchAlgorithmException {

        this.HashedPassword = hashedPassword;

    }

    public static String hashPassword(String password) throws NoSuchAlgorithmException { //package access
        // Create a MessageDigest instance for SHA-256
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        // Perform the hash
        byte[] hashedBytes = md.digest(password.getBytes());

        // Convert the byte array to a hexadecimal string
        StringBuilder sb = new StringBuilder();
        for (byte b : hashedBytes) {
            sb.append(String.format("%02x", b));
        }

        return sb.toString();
    }


    public String getPW(){return this.HashedPassword;}
    public void setPW(String newPW) throws NoSuchAlgorithmException {this.HashedPassword = hashPassword(newPW);}
}
