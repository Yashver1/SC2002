package enitities;

public enum Role {
	UNINVOLVED,
	CREATOR,
	ATTENDEE,
	COMMITTEE,
	BLACKLISTED
}