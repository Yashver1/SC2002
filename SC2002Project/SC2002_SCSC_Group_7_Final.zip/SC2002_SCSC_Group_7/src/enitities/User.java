
package enitities;

public class User {
    private String name;
    private String email;
    private Faculty faculty;
    private String networkID;
    private Password encypted_password;


    public User(String name, String email, Faculty faculty, String NetworkID, Password password) {
        this.name = name;
        this.email = email;
        this.faculty = faculty;
        this.networkID = NetworkID;
        this.encypted_password = password;
    }

    public User() {

    }

    public String getName() {
        return this.name;
    }

    public String getEmail() {
        return this.email;
    }

    public Faculty getFaculty() {
        return this.faculty;
    }

    public String getNetworkID() {return this.networkID;}

    public void printUserAttributes(){
        System.out.print("Name: " + getName());
        System.out.print("\tFaculty: " + getFaculty());
        System.out.println("\tNetwork ID: " + getNetworkID());
    }
    public Password getEncypted_password(){
        return this.encypted_password;
    }

}
