package enitities;
import java.util.Scanner;

public class Enquiry {
	private String sender;
	private String campName;
	private String message;
	private String status;
	private String reply;
	private String enquiryResponder;

	private static Scanner scanner = new Scanner(System.in);

	public Enquiry(String sender, String campName, String message, String status, String reply, String enquiryResponder){
		this.sender = sender;
		this.campName = campName;
		this.message = message;
		this.status = status;
		this.reply = reply;
		this.enquiryResponder = enquiryResponder;
	}
	public Enquiry(){

	}

	public void setSender(String string) {
		this.sender = string;
	}

	public void setCampName(String campName) {

		this.campName = campName;

	}

	public void setMessage() {
		System.out.println("Enter new message:");
		this.message = scanner.nextLine();
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setReply(String text) {
		this.reply = text;
	}

	public String getSender() {
		return this.sender;
	}

	public String getCampName() {
		return this.campName;
	}

	public String getMessage() {
		return this.message;
	}

	public String getStatus() {
		return this.status;
	}

	public String getReply() {
		return this.reply;
	}

	public String getEnquiryResponder() {
		return this.enquiryResponder;
	}

	public void setEnquiryResponder(String enquiryResponder) {
		this.enquiryResponder = enquiryResponder;
	}

	public void printEnquiryDetails() {
		System.out.print("{" + campName + "} " + " " + sender + ": \"" + message + "\" --- Status:{" + status + "} ");

		if (!getEnquiryResponder().isEmpty()) {
			System.out.println("Reply from " + getEnquiryResponder() + ": " + reply);
		}

		System.out.print("\n");
	}

}
