package enitities;
import java.util.Scanner;

public class Suggestion {

	private String sender;
	private String campName;
	private String message;
	private String status;





	private static Scanner scanner = new Scanner(System.in);

	public Suggestion(String sender, String campName, String message, String status) {
		this.sender = sender;
		this.campName = campName;
		this.message = message;
		this.status = status;

	}

	public Suggestion(){}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public void setCampName(String campName) {
		this.campName = campName;
	}

	public void setMessage() {
		System.out.println("Enter message:");
		this.message = scanner.nextLine();
	}

	public void setStatus(String status) {
		this.status = status;
	}



	public String getSender() {
		return this.sender;
	}

	public String getCampName() {
		return this.campName;
	}

	public String getMessage() {
		return this.message;
	}

	public String getStatus() {
		return this.status;
	}



	public void printSuggestionDetails() {
		System.out.print("{" + campName + "} " + sender + ": \"" + message + "\"  --- Status:{" + status + "}");
		System.out.print("\n");
	}
}