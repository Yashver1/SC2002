package boundaries;
import java.io.FileNotFoundException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Scanner;

import controllers.CampCreationController;
import controllers.CampSuggestionsController;
import controllers.ChangePasswordController;
import controllers.ReportGeneratorController;
import controllers.StaffCampsModificationController;
import controllers.CampAuthorityController;
import enitities.Camp;
import enitities.Enquiry;
import enitities.Staff;
import enitities.Student;
import enitities.Suggestion;
import helpers.CampPrinter;

public class StaffDirectory {

	Staff staff;
	ArrayList<Student> allStudents;
	ArrayList<Staff> allStaffs;
	ArrayList<Camp> allCamps;
	ArrayList<Enquiry> allEnquiries;
	ArrayList<Suggestion> allSuggestions;

  	public StaffDirectory(Staff staff, ArrayList<Student> allStudents, ArrayList<Staff> allStaffs, ArrayList<Camp> allCamps, ArrayList<Enquiry> allEnquiries, ArrayList<Suggestion> allSuggestions) throws NoSuchAlgorithmException, FileNotFoundException {
		this.staff = staff;
		this.allCamps = allCamps;
		this.allStudents = allStudents;
		this.allStaffs = allStaffs;
		this.allEnquiries = allEnquiries;
		this.allSuggestions = allSuggestions;

		while (true){
			if (directToController()) break;
		}
		System.out.println("Logging out...");
	}

  public void printMenu() {
    // TODO - implement StaffDirectory.printMenu
    
	System.out.println("*******************************************");
	System.out.println("*              	MAIN MENU            	  *");
	System.out.println("*******************************************");
	System.out.println("--------------Password Manager-------------");
	System.out.println("* 1. Change my password                   *");
	System.out.println("*                                         *");
	System.out.println("----------------Camps Manager--------------");
	System.out.println("* 2. View all camps                       *");
	System.out.println("* 3. Create camp                          *");
	System.out.println("* 4. View and modify my camps             *");
	System.out.println("* 5. Generate report of my camps          *");
	System.out.println("*                                         *");
	System.out.println("--------------Enquiries matters------------");
	System.out.println("* 6. View/reply enquiries sent to my camps*");
	System.out.println("*                                         *");
	System.out.println("-------------Suggestions matters-----------");
	System.out.println("* 7. View/approve suggestions to my camps *");
	System.out.println("*                                         *");
	
	
	System.out.println("*******************************************");
	System.out.println("* 0. Logout                   	          *");
	System.out.print("Your choice: ");

    System.out.println("");
    // throw new UnsupportedOperationException();
  }

  public boolean directToController() throws NoSuchAlgorithmException, FileNotFoundException {
	Scanner sc = new Scanner(System.in);
	printMenu();
	int choice = sc.nextInt();

	switch (choice) {

		case 1:
			ChangePasswordController cpc = new ChangePasswordController(staff,allStudents,allStaffs);
			return false;
		case 2:
			Scanner scan = new Scanner(System.in);
			while (true){
			CampPrinter cp = new CampPrinter(staff, allCamps);
			cp.viewAllCamps();
			System.out.print("Return to main (Y/N): ");
			String quit = scan.nextLine();
			if (quit.equals("Y")){
				break;
			}
			}
			return false;

		case 3:
			CampCreationController ccc = new CampCreationController(allCamps, staff); // change the _____ after creation
			return false;

		case 4:
			StaffCampsModificationController scmc = new StaffCampsModificationController(allCamps, staff);
			return false;
		case 5:
			ReportGeneratorController rgc = new ReportGeneratorController(staff,allCamps,allStudents,allStaffs);
			return false;


		case 6:
			CampAuthorityController cac = new CampAuthorityController(staff,allCamps,allEnquiries); ///synchronise show message for case 5
			return false;

		case 7:
			CampSuggestionsController csc = new CampSuggestionsController(staff, allSuggestions, allStudents); ///synchronise show message for case 4
			return false;

		case 0:
			return true;
			
		default:
			System.out.print("Invalid choice. 0 to return to main menu. ");
			return false;
	}


  }

}