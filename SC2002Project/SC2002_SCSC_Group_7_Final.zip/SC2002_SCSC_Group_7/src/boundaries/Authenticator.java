package boundaries;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.List;
import enitities.Password;
import controllers.*;
import enitities.*;
import helpers.*;

public class Authenticator {

    private boolean permitted;

    public Authenticator(){this.permitted = false;}


    public void setPermitted(String userID, Password hashedPassword, List<Map<String, String>> passwordList, String userType) throws NoSuchAlgorithmException {
        for (Map<String, String> record : passwordList) {
            if (record.get("NetworkID").equals(userID) && record.get("HashedPassword").equals(hashedPassword.getPW()) && record.get("UserType").equals(userType.toUpperCase())) {
                this.permitted = true;
                return;
            }
        }
    }

    public boolean getPermitted(){
        return this.permitted;
    }

}
