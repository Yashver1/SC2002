package controllers;

public interface Controller {

	boolean getUserInput();

	void printMenu();

}