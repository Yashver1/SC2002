package controllers;
public interface selectSuggestion {

	// /**
	//  * 
	//  */
	void selectSuggestion();

}