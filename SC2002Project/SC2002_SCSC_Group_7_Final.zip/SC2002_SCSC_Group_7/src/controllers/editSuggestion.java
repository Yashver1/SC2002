package controllers;
public interface editSuggestion {

	/**
	 * 
	 */
	void editSuggestion();

}