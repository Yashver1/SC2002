package controllers;
public interface editEnquiry {

	// /**
	//  * 
	//  * @param enquiry
	//  */
	void editEnquiry();

}