package controllers;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public interface generalCampReport {

	/**
	 *
	 */
	void generalCampReport() throws FileNotFoundException;

}