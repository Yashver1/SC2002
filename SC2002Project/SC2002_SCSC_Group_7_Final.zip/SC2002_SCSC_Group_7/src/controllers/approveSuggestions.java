package controllers;
public interface approveSuggestions {

	/**
	 *
	 * @param suggestion
	 */
	void approveSuggestions();

}