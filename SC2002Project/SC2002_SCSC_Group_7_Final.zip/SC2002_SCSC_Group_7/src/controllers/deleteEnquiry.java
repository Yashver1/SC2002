package controllers;
public interface deleteEnquiry {

	// /**
	//  * 
	//  * @param enquiryRecords
	//  */
	void deleteEnquiry();

}