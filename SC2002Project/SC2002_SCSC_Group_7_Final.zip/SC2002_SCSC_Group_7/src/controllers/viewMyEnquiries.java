package controllers;
public interface viewMyEnquiries {

	// /**
	//  * 
	//  * @param user
	//  * @param enquiryRecords
	//  */
	void viewMyEnquiries();

}