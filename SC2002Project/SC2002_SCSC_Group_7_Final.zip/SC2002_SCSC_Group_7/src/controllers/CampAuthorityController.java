package controllers;
import java.util.ArrayList;
import java.util.Scanner;

import enitities.Camp;
import enitities.Enquiry;
import enitities.Staff;
import enitities.Student;
import enitities.User;

public class CampAuthorityController implements viewEnquiries, replyEnquiries, selectEnquiry, Controller{ 


    User user;
    ArrayList<String> myCamplist = new ArrayList<String>();
    ArrayList<Enquiry> EnquiryList;
    Enquiry selectedEnquiry;

    ArrayList<Enquiry> myEnquiries = new ArrayList<Enquiry>() ;

    public CampAuthorityController(User user,ArrayList<Camp> Camplist,ArrayList<Enquiry> EnquiryList){
        this.user= user;
        this.EnquiryList = EnquiryList;

        if (user instanceof Staff){
            Staff staff = (Staff) user;
            for (Enquiry eq : EnquiryList){
                if (staff.getCreatedCamps().contains(eq.getCampName())){
                    myEnquiries.add(eq);
                }
            }
        }
        else if (user instanceof Student){
            Student student = (Student) user;
            for (Enquiry eq: EnquiryList){
                if (student.getCampCommittee().contains(eq.getCampName())){
                    myEnquiries.add(eq);
                }
            }
        }

        while (true){
            if (myEnquiries.isEmpty()){
                System.out.println("No enquiries found.");
                break;
            }

            if (getUserInput()){ 
                break;
            }
        }
        System.out.println("Returning you to main menu...");
    }

    public void selectEnquiry(){
        System.out.println("Select enquiry to reply to: ");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        if (choice> myEnquiries.size() || choice < 1){
            System.out.println("Invalid input.");
            return;
        }
        selectedEnquiry = myEnquiries.get((choice - 1));
    }

	public void viewEnquiries() {
        int i = 1;
        for(Enquiry enquiry: myEnquiries){
            System.out.print("(" + (i) + ")" + " ");
            i++;
            enquiry.printEnquiryDetails();
            enquiry.setStatus("VIEWED");
        }
        System.out.println("(0) Return");

    }


	public void replyEnquiries() {
        viewEnquiries();
        selectEnquiry();
        if (selectedEnquiry == null) return;
        if (!selectedEnquiry.getReply().isEmpty()){
            System.out.println("Enquiry has already been replied to.");
            return;
        }

        Scanner sc = new Scanner(System.in);
        System.out.print("Reply: ");
        String reply = sc.nextLine();
        selectedEnquiry.setEnquiryResponder(this.user.getNetworkID());
        selectedEnquiry.setReply(reply);

        if (user instanceof Student){
            ((Student)user).addPoints(1);
        }

	}

    public void printMenu(){
        System.out.println("Select what you wish to do: ");
            System.out.println("(1) View Enquiries");
            System.out.println("(2) Reply Enquiries");
            System.out.println("(0) Return to main menu");
            System.out.print("Your choice: ");  

    }


    public boolean getUserInput(){
        Scanner sc = new Scanner(System.in);
        printMenu();
        int choice = sc.nextInt();
        switch(choice){
            case 1:
                viewEnquiries();
                return false;
            case 2:
                replyEnquiries();
                return false;

            case 0:
                return true;
            
            default:
            System.out.print("Invalid choice. 0 to return to main menu. ");
                return false;
        }

    }

}
