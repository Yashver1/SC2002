package controllers;
import java.util.List;
import java.util.Map;

public interface quitCamp {

	/**
	 * 
	 * @param student
	 * @param usercampRecords
	 */
	void quitCamp();

}