package controllers;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import enitities.User;

public interface changePassword {
    public void changePassword(User user) throws NoSuchAlgorithmException;
}
