package controllers;
public interface viewEnquiries {

	/**
	 *
	 * @param user
	 * @param enquiryRecords
	 */
	void viewEnquiries();

}