package controllers;
public interface viewMySuggestions {

	/**
	 *

	 */
	void viewMySuggestions();

}