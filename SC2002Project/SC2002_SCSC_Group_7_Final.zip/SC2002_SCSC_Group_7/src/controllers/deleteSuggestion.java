package controllers;
public interface deleteSuggestion {

	/**
	 *
	 */
	void deleteSuggestion();

}