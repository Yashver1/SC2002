package controllers;
import java.util.ArrayList;
import java.util.Scanner;

import enitities.Enquiry;
import enitities.Student;


public class MyEnquiryController implements deleteEnquiry, viewMyEnquiries, editEnquiry, selectEnquiry, Controller {

    int choice;
    Student student;
    ArrayList<Enquiry> allEnquiries = new ArrayList<Enquiry>();
    ArrayList<Enquiry> myEnquiries = new ArrayList<Enquiry>();
    Enquiry enquiryToModify;

    public MyEnquiryController(Student student, ArrayList<Enquiry> allEnquiries){
        this.student = student;
        this.allEnquiries = allEnquiries;

        for (Enquiry enq: allEnquiries){
            if(enq.getSender().equals(student.getNetworkID())){
                myEnquiries.add(enq);
            }
        }
        while (true){
            if (myEnquiries.isEmpty()){
                System.out.println("No enquiries found.");
                break;
        }
            if (getUserInput()){ 
                break;
            }
        }
        System.out.println("Returning you to main menu...");
    }
    public void viewMyEnquiries() {
        int i = 1;
        for (Enquiry enquiry : myEnquiries){
            System.out.print("(" + (i) + ")" + " ");
            i++;
            enquiry.printEnquiryDetails();       
         }
    }

    public void editEnquiry(){
        viewMyEnquiries();
        selectEnquiry();
        // if (myEnquiries.isEmpty()){
        //     return;
        // }
        if(enquiryToModify.getStatus().equals("VIEWED")){
            System.out.println("Enquiry has been viewed, you cannot edit it.");
            return;        
        }
        enquiryToModify.setMessage();    
    }
    
    public void deleteEnquiry() {
        viewMyEnquiries();
        selectEnquiry();
        if(enquiryToModify.getStatus().equals("VIEWED")){
            System.out.println("Enquiry has been viewed, you cannot delete it.");
            return;        
        }
        allEnquiries.remove(enquiryToModify);
        myEnquiries.remove(enquiryToModify);    
    }

    public void selectEnquiry(){
        System.out.println("Select the enquiry you wish to modify: ");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        if (choice> myEnquiries.size() || choice < 1){
            System.out.println("Invalid input.");
            return;
        }
        enquiryToModify = myEnquiries.get(choice-1);
    }

    public void printMenu(){
        System.out.println("Select function you want to do: "); 
        System.out.println("(1) Edit Enquiry");
        System.out.println("(2) Delete Enquiry");
        System.out.println("(3) View Enquiries");
        System.out.println("(0) Return to main menu");
        System.out.print("Your choice: ");

    }

    public boolean getUserInput(){
        printMenu();
        Scanner ch = new Scanner(System.in);
        choice = ch.nextInt();
        switch (choice){
            case 1:
                editEnquiry();
                return false;

            case 2:
                deleteEnquiry();
                return false;
            
            case 3:
                viewMyEnquiries();
                return false;
            
            case 0:
                return true;
            default:
                System.out.print("Invalid choice. 0 to return to main menu. ");
                return false;
        }

    }
}