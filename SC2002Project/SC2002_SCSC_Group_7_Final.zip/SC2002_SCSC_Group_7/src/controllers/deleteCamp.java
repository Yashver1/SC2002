package controllers;
public interface deleteCamp {

	/**
	 * 
	 * @param campInfoRecords
	 * @param usercampRecords
	 * @param staff
	 */
	void deleteCamp();

}