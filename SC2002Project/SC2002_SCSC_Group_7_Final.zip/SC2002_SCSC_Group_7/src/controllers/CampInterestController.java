package controllers;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import enitities.Camp;
import enitities.Enquiry;
import enitities.Student;
import helpers.CampGenerator;
import helpers.CampPrinter;
import helpers.DateHandler;

public class CampInterestController implements registerAsCommittee, registerAsAttendee, Controller {

    ArrayList <Camp> allCamps;
    ArrayList <Camp> myCamps = new ArrayList<Camp>();
    ArrayList <Enquiry> allEnquiries;
    Student student;
    Camp campToRegister;

    public CampInterestController(ArrayList<Camp> allCamps, ArrayList <Enquiry> allEnquiries, Student student){
        this.student = student;
        this.allCamps = allCamps;
        this.allEnquiries = allEnquiries;
        CampPrinter cp = new CampPrinter(student, allCamps);

        while(true){
            CampGenerator cg = new CampGenerator(student, allCamps);
            myCamps = cg.generateMyCamps();
            cp.viewAllCamps();
            System.out.println("(0) Go back");
            cp.setCampToInteract();
            if (cp.getCampToInteract() == null){ 
                break;
            }
            campToRegister = cp.getCampToInteract();

            if (getUserInput()){
                break;
            }    
        
        }
        System.out.println("Returning you to main menu...");
    }
        


	public void registerAsCommittee() {
        String campName = campToRegister.getName();
        int currentSize = campToRegister.getCommitteeList().size() + campToRegister.getAttendeeList().size();

        if (student.getCampCommittee().contains(campName)){
            System.out.println("You are already in this camp as a committee.");
            return;
        }

        if (student.getCampAttendee().contains(campName)){
            System.out.println("You are already in this camp as an attendee.");
            return;
        }
		if (student.getCampCommittee().size() == Student.getMAX()){
            System.out.println("You could only register for up to " + Student.getMAX() + " camps as a committee.");
            return;
        }

        if (campToRegister.getCommitteeList().size() > campToRegister.getCommitteeSlots()){
            System.out.println("The camp committee is already full.");
            return;
        }

        if (currentSize >= campToRegister.getTotalSlots() || campToRegister.getClosingDate().isBefore(LocalDate.now())){
            System.out.println("Camp is closed for registration");
            return;
        }

        if (student.getBlackListCamp().contains(campName)){
            System.out.println("You are not allowed to register for this camp");
            return;
        }


        
        for (Camp camp: myCamps){
            if(DateHandler.CampClashes(camp, campToRegister)){
                System.out.println(campToRegister.getName() + " clashes with " + camp.getName());
                System.out.println("You cannot register.");
                return;
            }
        }

        campToRegister.addToCommitteeList(student.getNetworkID());
        student.addToCommitteeCamp(campName);
        System.out.println("You have successfully registered as a committee member for "+ campName);

        
	}

	/**
	 *
	 */
	public void registerAsAttendee() {
        String campName = campToRegister.getName();
        int currentSize = campToRegister.getCommitteeList().size() + campToRegister.getAttendeeList().size();

        if (student.getCampCommittee().contains(campName)){
            System.out.println("You are already in this camp as a committee.");
            return;
        }

        if (student.getCampAttendee().contains(campName)){
            System.out.println("You are already in this camp as an attendee.");
            return;
        }

        if (student.getBlackListCamp().contains(campName)){
            System.out.println("You are not allowed to register for this camp");
            return;
        }

        if (currentSize >= campToRegister.getTotalSlots() || campToRegister.getClosingDate().isBefore(LocalDate.now())){
            System.out.println("Camp is closed for registration");
            return;
        }
       
        for (Camp camp: myCamps){
            if(DateHandler.CampClashes(camp, campToRegister)){
                System.out.println(campToRegister.getName() + " clashes with " + camp.getName());
                System.out.println("You cannot register.");
                return;
            }
        }

        System.out.println("You have successfully registered as a member for "+ campName);
        campToRegister.addToAttendee(student.getNetworkID());
        student.addToAttendeeCamp(campName);
    

    }

    public void createEnquiry() {
        if (student.getCampCommittee().contains(campToRegister.getName())){
            System.out.println("You cannot send an enquiry to a camp you are committee of.");
            return;
        }
        Enquiry enquiry = new Enquiry();
        enquiry.setSender(student.getNetworkID());
        String campName = campToRegister.getName();
        enquiry.setCampName(campName);
        enquiry.setMessage();
        enquiry.setStatus("UNVIEWED");
        enquiry.setReply("");
        enquiry.setEnquiryResponder("");


        System.out.println("Enquiry has been created, view in mailbox");
        allEnquiries.add(enquiry);

    }



    public void printMenu(){
        System.out.println("Select what you wish to do: ");
        System.out.println("(1) Sign up as committee member");
        System.out.println("(2) Sign up as regular member");
        System.out.println("(3) Submit an enquiry");
        System.out.println("(0) Return to main menu");
        System.out.print("Your choice: ");
    }

    public boolean getUserInput(){
        Scanner sc = new Scanner(System.in);
        printMenu();
        int choice = sc.nextInt();
        switch(choice){
            case 1:
                registerAsCommittee();
                return false;
            case 2:
                registerAsAttendee();
                return false;

            case 3:
                createEnquiry();
                return false;
            
            case 0:
                return true;
            default:
                System.out.print("Invalid choice. 0 to return to main menu. ");
                return false;
        }

    }




}