package controllers;
public interface viewSuggestions {
    public void viewSuggestions();
}
