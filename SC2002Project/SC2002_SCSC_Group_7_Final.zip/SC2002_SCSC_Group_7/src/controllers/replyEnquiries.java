package controllers;
public interface replyEnquiries {


	void replyEnquiries();

}