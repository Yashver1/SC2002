package controllers;
public interface createEnquiry {

	/**
	 *
	 */
	void createEnquiry();

}