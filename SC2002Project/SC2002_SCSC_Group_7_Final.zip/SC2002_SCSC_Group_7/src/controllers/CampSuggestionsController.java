package controllers;

import java.util.ArrayList;
import java.util.Scanner;

import enitities.Staff;
import enitities.Student;
import enitities.Suggestion;
import controllers.*;
import enitities.*;
import helpers.*;


public class CampSuggestionsController implements viewSuggestions, approveSuggestions, Controller {

	Staff staff;
    ArrayList<Suggestion> allSuggestions;
    ArrayList<Student> allStudents;
    ArrayList<Suggestion> myCampSuggestions = new ArrayList<Suggestion>();
    Suggestion sgToInteract;

	public CampSuggestionsController(Staff staff, ArrayList <Suggestion> allSuggestions, ArrayList<Student> allStudents){
        this.staff = staff;
        this.allSuggestions = allSuggestions;
        this.allStudents = allStudents;
        int x = 1;
        for (Suggestion sg : allSuggestions){
            if (staff.getCreatedCamps().contains(sg.getCampName())){
                myCampSuggestions.add(sg);
                System.out.print("(" + x +")");
                sg.printSuggestionDetails();
                if (sg.getStatus().equals("UNVIEWED")) sg.setStatus("VIEWED");
                x++;
            }
        }


        while(true){
            if (myCampSuggestions.isEmpty()){
                System.out.println("No suggestions found.");
                break;
            }
            if (getUserInput()){ 
                break;
            }
        }
        System.out.println("Returning you to main menu...");
	}
	/**
	 */
	public void viewSuggestions() {
        int x  = 1;
        for (Suggestion sg : myCampSuggestions){
                System.out.print("(" + x +")");
                sg.printSuggestionDetails();
                x++;
            }
        System.out.println("(0) Return");

}
	

    public void selectSuggestion(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Select the suggestion you wish to approve: ");
        int sgChoice = sc.nextInt();
        if (sgChoice> myCampSuggestions.size() || sgChoice < 1){
            System.out.println("Invalid input.");
            return;
        }
        sgToInteract = myCampSuggestions.get((sgChoice - 1));
    }

	/**
	 *
	 */
	public void approveSuggestions(){
        viewSuggestions();
        selectSuggestion();
        if (sgToInteract == null) return;
        if (sgToInteract.getStatus().equals("APPROVED")){
            System.out.println("Suggestion has already been approved.");
            return;
        }

        sgToInteract.setStatus("APPROVED");
        String studentName = sgToInteract.getSender();
        for (Student std: allStudents){
            if(std.getNetworkID().equals(studentName)){
                std.addPoints(1);
            }
        }

        System.out.println("Suggestion has been approved.");
        System.out.println("Make necessary amendments in the modifications menu.");
    }

    public void printMenu(){
        System.out.println("Select function you want to do: ");
        System.out.println("(1) View all suggestions.");
        System.out.println("(2) Approve a suggestion.");
        System.out.println("(0) Return to main menu");
        System.out.print("Enter the desired function:");
    }

    public boolean getUserInput(){
        printMenu();
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();

        switch(choice){
            case 1:
                viewSuggestions();
                return false;

            case 2:
                approveSuggestions();
                return false;

            case 0:
                return true;

            default:
                System.out.print("Invalid choice. 0 to return to main menu. ");
                return false;

            
        }
    }
}

