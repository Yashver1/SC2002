package controllers;
public interface createSuggestion {


	void createSuggestion();

}