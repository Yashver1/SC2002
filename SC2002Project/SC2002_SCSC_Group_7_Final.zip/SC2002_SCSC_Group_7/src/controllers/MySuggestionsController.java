package controllers;
import java.util.*;

import javax.swing.text.AbstractDocument.Content;

import enitities.Student;
import enitities.Suggestion;

public class MySuggestionsController implements Controller, viewMySuggestions, editSuggestion,deleteSuggestion, selectSuggestion { //createSuggestion, deleteSuggestion

    int choice;
    Student student;
    ArrayList<Suggestion> suggestionList = new ArrayList<Suggestion>();
    ArrayList<Suggestion> mySuggestions = new ArrayList<Suggestion>();
    Suggestion suggestionToModify;

    public MySuggestionsController(Student student, ArrayList<Suggestion> suggestionList) {
        this.student = student;
        this.suggestionList = suggestionList;


        for (Suggestion suggestion : suggestionList) {
            if (suggestion.getSender().equals(student.getNetworkID())) {
                mySuggestions.add(suggestion);
            }
        }


        while (true){
            if (mySuggestions.isEmpty()){
                System.out.println("No suggestions found.");
                break;
            }
            boolean quitStatus = getUserInput();
            if (quitStatus){ 
                break;
            }
        }
        System.out.println("Returning you to main menu...");
    }


    public void viewMySuggestions() {
        int i = 1;
        for (Suggestion suggestion : mySuggestions) {
            System.out.print("(" + (i) + ")" + " ");
            i++;
            suggestion.printSuggestionDetails();
        }
    }

    public void editSuggestion() {
        viewMySuggestions();
        selectSuggestion();
        if (suggestionToModify.getStatus().equals("VIEWED") || suggestionToModify.getStatus().equals("APPROVED")) {
            System.out.println("Suggestion is processing, you cannot edit it.");
            return;
        }
        suggestionToModify.setMessage();
    }

    public void deleteSuggestion() {
        viewMySuggestions();        
        selectSuggestion();
        if (suggestionToModify.getStatus().equals("VIEWED") || suggestionToModify.getStatus().equals("APPROVED")) {
            System.out.println("Suggestion is processing, you cannot delete it.");
            return;
        }

        suggestionList.remove(suggestionToModify);
        mySuggestions.remove(suggestionToModify);
    }
    public void selectSuggestion(){
        System.out.println("Select the Suggestion you wish to modify");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        if (choice> mySuggestions.size() || choice < 1){
            System.out.println("Invalid input.");
            return;
        }
        suggestionToModify = mySuggestions.get(choice - 1);
    }

    public void printMenu(){
        System.out.println("Select function you want to do: "); 
        System.out.println("(1) Edit Suggestion");
        System.out.println("(2) Delete Suggestion");
        System.out.println("(3) View suggestions");
        System.out.println("(0) Return to main menu");
        System.out.print("Your choice: ");

    }

    public boolean getUserInput(){
        printMenu();
        Scanner ch = new Scanner(System.in);
        int choice = ch.nextInt();
        switch (choice){
            case 1:
                editSuggestion();
                return false;

            case 2:
                deleteSuggestion();
                return false;
            
            case 3:
                viewMySuggestions();
                return false;

            case 0:
                return true;
            default:
                System.out.print("Invalid choice. 0 to return to main menu. ");
                return false;
        }

    }

}




