package controllers;
import java.util.List;

public interface registerAsAttendee {


	void registerAsAttendee();

}