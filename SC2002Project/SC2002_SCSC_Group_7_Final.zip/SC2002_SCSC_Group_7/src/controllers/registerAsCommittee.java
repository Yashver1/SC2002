package controllers;
import java.util.List;

public interface registerAsCommittee {


	void registerAsCommittee();

}