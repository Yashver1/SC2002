package controllers;
import java.security.AllPermission;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import enitities.Camp;
import controllers.*;
import enitities.*;
import helpers.*;
import enitities.Staff;

import java.time.LocalDate;

public class StaffCampsModificationController implements editCamp, Controller, deleteCamp { 

	/**
	 *
	 */
    int userInput = 0;
    Staff staff;
    ArrayList <Camp> allCamps = new ArrayList<Camp>();
    Camp campToInteract;

     public StaffCampsModificationController(ArrayList <Camp> allCamps, Staff staff){
        this.staff = staff;
        this.allCamps = allCamps;

        while (true){
            this.allCamps = allCamps;
            CampPrinter cp = new CampPrinter(staff, allCamps);
            cp.viewMyCamps();
            if (cp.getCampsAvailable().size() == 0){
                // System.out.println("No camps found.");
                break;
            }
            System.out.println("(0) Return");
            cp.setCampToInteract();
            
            if (cp.getCampToInteract() == null){
                break;
            }
            campToInteract = cp.getCampToInteract();

            if (getUserInput()){ 
                break;
            }
        }
        System.out.println("Returning you to main menu...");
    }

     
	/**
	 *
	 */

	public void editCamp() {

        Scanner sc = new Scanner(System.in);
        System.out.println("Select what you want to edit:");
        System.out.println("(1) Camp description");
        System.out.println("(2) Camp dates");
        System.out.println("(3) Camp location");
        System.out.println("(4) Committee slots");
        System.out.println("(5) Total slots");
        System.out.println("(6) Faculty open to");
        System.out.println("(7) Visibility");
        System.out.println("(0) Abandon");
        System.out.print("Your choice: "); int choice = sc.nextInt();


        switch (choice) {
            case 1:
                campToInteract.setDescription();
                break;
            case 2:
                campToInteract.setStartDate(); 
                campToInteract.setEndDate();
                campToInteract.setClosingDate();
                break;
            case 3:
                campToInteract.setLocation();
                break;

            case 4:
                campToInteract.setCommitteeSlots();
                break;
            case 5:
            campToInteract.setTotalSlots();
                break;
            case 6:
                System.out.println("Allow all students outside " + staff.getFaculty() + "? (T/F)");
                Scanner openS = new Scanner(System.in);
                String openString = openS.nextLine();

                if (openString.equals("T")){campToInteract.setOpenTo(Faculty.NTU);}
                else {campToInteract.setOpenTo(staff.getFaculty());}

                break;
            case 7:
                campToInteract.setVisibility();
                break;
            default:
                break;
        }
        return;
	}

	/**
	 *
	 */

    public void deleteCamp() {
        if (campToInteract.getCommitteeList().size() != 0 || campToInteract.getAttendeeList().size() != 0){
            System.out.println("Camp cannot be deleted as there are students already...");
            return;
        }

        for (int i = 0; i< allCamps.size(); i ++){
            if(allCamps.get(i).equals(campToInteract)) allCamps.remove(i);
        }
    }   

    public void printMenu(){
        System.out.println("Select function you want to do: ");
        System.out.println("1) Edit camp");
        System.out.println("2) Delete camp");
        System.out.println("0) Return to main menu");
        System.out.print("Your choice: ");
    }

    public boolean getUserInput(){
        Scanner sc = new Scanner(System.in);
        printMenu();
        userInput = sc.nextInt();
        switch(userInput){

            case 1: 
                editCamp();
                return false;

            case 2:
                deleteCamp();
                return false;
                
            case 0:
                return true;
            default:
                System.out.print("Invalid choice. 0 to return to main menu. ");
                return false;


        }

    }

}