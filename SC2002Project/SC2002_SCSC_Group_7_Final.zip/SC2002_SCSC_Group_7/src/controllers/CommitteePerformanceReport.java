package controllers;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public interface CommitteePerformanceReport {

    public void CommitteePerformanceReport() throws FileNotFoundException;
}
