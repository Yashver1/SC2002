package controllers;
public interface editCamp {

	/**
	 * 
	 * @param camp
	 */
	void editCamp();

}