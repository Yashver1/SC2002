package controllers;
import java.util.ArrayList;
import java.util.Scanner;

import enitities.Camp;
import enitities.Student;
import enitities.Suggestion;
import controllers.*;
import enitities.*;
import helpers.*;
public class RegisteredCampsController implements quitCamp, Controller {

	/**
	 *
	 */
    Student student;
    ArrayList<Camp> allCamps;
    ArrayList <Suggestion> allSuggestions;
    ArrayList<Camp> myCamps = new ArrayList<Camp>();

     public RegisteredCampsController(Student student, ArrayList <Camp> allCamps, ArrayList <Suggestion> allSuggestions){
        this.student = student;
        this.allCamps = allCamps;
        this.allSuggestions = allSuggestions;
        while (!getUserInput());
        System.out.println("Returning you to main menu...");
        }
        


    public void quitCamp() {
        Scanner sc = new Scanner(System.in);
        CampGenerator cg = new CampGenerator(student, allCamps);
        myCamps  = cg.generateMyAttendeeCamps();
        if (myCamps.isEmpty()){
            System.out.println("You do not have any camps available to quit from.");
            return;
        }

        System.out.println("You can only quit from: ");
        int x = 1;
        for (Camp camp: myCamps){
            System.out.print("(" + x + ")");
            camp.printAttributes();
        }
        System.out.println("(0) Return");
        System.out.print("Enter choice: ");
        int choice = sc.nextInt();
        if (choice == 0) return;
        if (choice < 1 || choice > myCamps.size()){
            System.out.println("Invalid choice");
            return;
        }
        Camp campToQuit = myCamps.get(choice - 1);
        String campName = campToQuit.getName();

        campToQuit.removeFromAttendeeList(student.getNetworkID());
        campToQuit.addToBlackList(student.getNetworkID());
        student.removeFromAttendeeCamp(campName);
        student.addToBlackListCamp(campName);

        System.out.println("You are now removed from " + campName + ". You cannot rejoin anymore...");
    }

    public void createSuggestion(){
        Scanner sc = new Scanner(System.in);
        CampGenerator cg = new CampGenerator(student, allCamps);
        myCamps  = cg.generateMyCommitteeCamps();

        if (myCamps.isEmpty()){
            System.out.println("You are not part of any committee ");
            return;
        }

        System.out.println("You can only submit suggestions to: ");
        int x = 1;
        for (Camp camp: myCamps){
            System.out.print("(" + x + ")");
            camp.printAttributes();
        }
        System.out.print("Enter choice: ");
        int choice = sc.nextInt();
        Camp campToSuggest = myCamps.get(choice - 1);
        String campName = campToSuggest.getName();

        Suggestion sg = new Suggestion();
        sg.setCampName(campName);
        sg.setMessage();
        sg.setSender(student.getNetworkID());
        sg.setStatus("UNVIEWED");
        allSuggestions.add(sg);
        student.addPoints(1);
        System.out.println("Suggestion has been created, view in mailbox");

    }

    public void viewRegisteredCamps(){
        CampGenerator cg = new CampGenerator(student, allCamps);
        if (cg.generateMyAttendeeCamps().isEmpty() && cg.generateMyCommitteeCamps().isEmpty()){
            System.out.println("You do not have any camps.");
            return;
        }

        CampPrinter cp = new CampPrinter(student, allCamps);

        
        System.out.println("You are attending the following camps: ");
        if(student.getCampCommittee().size() != 0) System.out.println("=============COMMITTEE================");
        cp.viewMyCommitteeCamps();
        if(student.getCampAttendee().size() != 0)System.out.println("==============ATTENDEE================");
        cp.viewMyAttendeeCamps();
    }

    public void printMenu(){
        System.out.println("Select what you want to do: ");
        System.out.println("(1) View camps you are part of.");
        System.out.println("(2) Withdraw from camp.");
        if (!student.getCampCommittee().isEmpty()) System.out.println("(3) Create a suggestion");
        System.out.println("(0) Return to main menu");
        System.out.print("Your choice: ");

    }

    public boolean getUserInput(){
        printMenu();
        Scanner ch = new Scanner(System.in);
        int choice = ch.nextInt();
        switch (choice){
            case 1:
                viewRegisteredCamps();
                return false;

            case 2:
                quitCamp();
                return false;

            case 3:
                if (!student.getCampCommittee().isEmpty()) createSuggestion();
                else System.out.print("Invalid choice.");
                return false;
        
            case 0:
                return true;
                
            default:
                System.out.print("Invalid choice.");
                return false;
        }

    }


}