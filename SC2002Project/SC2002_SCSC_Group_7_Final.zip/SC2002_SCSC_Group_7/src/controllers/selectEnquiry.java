package controllers;
public interface selectEnquiry {

	// /**
	//  * 
	//  */
	void selectEnquiry();

}