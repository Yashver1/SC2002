package controllers;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Scanner;

import enitities.Staff;
import enitities.Student;
import enitities.User;

public class ChangePasswordController implements changePassword {
    ArrayList<Student> studentList;
    ArrayList <Staff> staffList;
    User user;
    public ChangePasswordController(User user,ArrayList<Student> allStudents, ArrayList <Staff> allStaffs) throws NoSuchAlgorithmException {
        this.staffList = allStaffs;
        this.studentList = allStudents;
        this.user = user;
        changePassword(user);
    }


    public void changePassword(User user) throws NoSuchAlgorithmException {
        if (user instanceof Student){
            for(Student student: studentList){
                if (user.getNetworkID().equals(student.getNetworkID())){
                    Scanner sc = new Scanner(System.in);
                    System.out.println("Enter your new password: ");
                    String password;
                    password = sc.next();
                    student.getEncypted_password().setPW(password);
                    return;
                }
            }

        }
        if (user instanceof Staff){
            for(Staff staff: staffList){
                if (user.getNetworkID().equals(staff.getNetworkID())){
                    Scanner sc = new Scanner(System.in);
                    System.out.println("Enter your new password: ");
                    String password;
                    password = sc.next();
                    staff.getEncypted_password().setPW(password);
                    return;
                }
            }
        }

    }

}
