package helpers;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import enitities.Camp;
import enitities.Student;
import enitities.User;
public class CampGenerator {
	/**
	 * 
	 * @param user
	 * 
	 */
	public User user;
	public ArrayList<Camp> allCamps;
	// public ArrayList<Camp> myCamps = new ArrayList<Camp>();

	 public CampGenerator(User user, ArrayList<Camp> allCamps){
		this.user = user;
		this.allCamps = allCamps;
	 }

	public ArrayList<Camp> generateMyCamps(){

		ArrayList <Camp> myCamps = new ArrayList<Camp>();

			Student s1 = (Student) user;
			int commSize =  s1.getCampCommittee().size();
			int attendSize = s1.getCampAttendee().size();
			String campName;


			for(int i = 0; i< commSize; i++){
				campName =  s1.getCampCommittee().get(i);
				for (int j = 0; j<allCamps.size(); j++){
					if(allCamps.get(j).getName().equals(campName)){ 
						myCamps.add(allCamps.get(j));
					}
				}
			}

			for(int q = 0; q< attendSize; q++){
				campName =  s1.getCampAttendee().get(q);
				for (int j = 0; j<allCamps.size(); j++){
					if(allCamps.get(j).getName().equals(campName)){ 
						myCamps.add(allCamps.get(j));
					}
				}
			}

			
		 return myCamps;
		
	}

	public ArrayList<Camp> generateMyAttendeeCamps(){

		ArrayList <Camp> myCamps = new ArrayList<Camp>();

			Student s1 = (Student) user;
			int attendSize = s1.getCampAttendee().size();
			String campName;


			for(int q = 0; q< attendSize; q++){
				campName =  s1.getCampAttendee().get(q);
				for (int j = 0; j<allCamps.size(); j++){
					if(allCamps.get(j).getName().equals(campName)){ 
						myCamps.add(allCamps.get(j));
					}
				}
			}
			
		return myCamps;
	}

	public ArrayList<Camp> generateMyCommitteeCamps(){

		ArrayList <Camp> myCamps = new ArrayList<Camp>();

			Student s1 = (Student) user;
			int commSize = s1.getCampCommittee().size();
			String campName;


			for(int q = 0; q< commSize; q++){
				campName =  s1.getCampCommittee().get(q);
				for (int j = 0; j<allCamps.size(); j++){
					if(allCamps.get(j).getName().equals(campName)){ 
						myCamps.add(allCamps.get(j));
					}
				}
			}
			
		return myCamps;
	}
}

	

