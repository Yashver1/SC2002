package helpers;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

public class CSVUtils {

    private static final String CSV_SEPARATOR = ",";

    // Original readCSV method
    public static ArrayList<Map<String, String>> readCSV(String filename) {
        ArrayList<Map<String, String>> records = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line = br.readLine();
            String[] headers = line.split(CSV_SEPARATOR);

            while ((line = br.readLine()) != null) {
                String[] values = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
                Map<String, String> row = new HashMap<>();
                for (int i = 0; i < headers.length; i++) {
                    String value = i < values.length ? values[i].replaceAll("^\"|\"$", "") : "";
                    row.put(headers[i], value);
                }
                records.add(row);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return records;
    }

    // Original writeCSV method
    public static void writeCSV(String filename, List<Map<String, String>> records) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
            if (!records.isEmpty()) {
                StringJoiner headerJoiner = new StringJoiner(CSV_SEPARATOR);
                records.get(0).keySet().forEach(headerJoiner::add);
                bw.write(headerJoiner.toString());
                bw.newLine();

                for (Map<String, String> record : records) {
                    StringJoiner recordJoiner = new StringJoiner(CSV_SEPARATOR);
                    for (String value : record.values()) {
                        recordJoiner.add(value);
                    }
                    bw.write(recordJoiner.toString());
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // New readCSVPreserveCommas method
    public static List<Map<String, String>> readCSVPreserveCommas(String filename) {
        List<Map<String, String>> records = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line = br.readLine();
            String[] headers = line.split(CSV_SEPARATOR, -1);

            while ((line = br.readLine()) != null) {
                String[] values = line.split(CSV_SEPARATOR + "(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
                Map<String, String> row = new HashMap<>();
                for (int i = 0; i < headers.length; i++) {
                    String value = i < values.length ? values[i].replaceAll("^\"|\"$", "") : "";
                    row.put(headers[i], value);
                }
                records.add(row);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return records;
    }

    // New writeCSVPreserveCommas method
    public static void writeCSVPreserveCommas(String filename, List<Map<String, String>> records) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
            if (!records.isEmpty()) {
                StringJoiner headerJoiner = new StringJoiner(CSV_SEPARATOR);
                records.get(0).keySet().forEach(headerJoiner::add);
                bw.write(headerJoiner.toString());
                bw.newLine();

                for (Map<String, String> record : records) {
                    StringJoiner recordJoiner = new StringJoiner(CSV_SEPARATOR);
                    for (String value : record.values()) {
                        recordJoiner.add(value);
                    }
                    bw.write(recordJoiner.toString());
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
// Helper method for quoting strings
    private static String quoteString(String value) {
        if (value == null) {
            return "";
        }
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }
}
